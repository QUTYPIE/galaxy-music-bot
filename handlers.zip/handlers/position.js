/**
 * Moved to ./functions.js
 */