/**
 * MOVED TO .counter.js
 */