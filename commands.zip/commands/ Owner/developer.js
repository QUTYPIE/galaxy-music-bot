const {
	MessageEmbed
} = require("discord.js")
const config = require(`${process.cwd()}/botconfig/config.json`)
var ee = require(`${process.cwd()}/botconfig/embed.json`)
const emoji = require(`${process.cwd()}/botconfig/emojis.json`);
const { MessageButton, MessageActionRow } = require('discord.js')
const { handlemsg } = require(`${process.cwd()}/handlers/functions`)
module.exports = {
	name: "about",
	category: "🔰 Info",
	aliases: ["info"],
	description: "Shows info about the bot",
	usage: "about",	
	type: "bot",
	run: async (client, message, args, cmduser, text, prefix) => {

  const b = new MessageButton()
      .setLabel(`INVITE VAYU RHYTHM`)
      .setURL(`https://discord.com/oauth2/authorize?client_id=997502155378401301&permissions=8&scope=bot`)
      .setStyle(`LINK`)
.setEmoji(`<a:online:1026095741179007056>`)    
            const bt = new MessageButton()
  .setLabel(`Support`)
    .setURL("https://discord.gg/Rqdx38Gdfn")
 .setStyle(`LINK`)                
      .setEmoji(`<a:TO_sus_stare:1004968406455439390>`)

      const website = new MessageButton()
  .setLabel(`INVITE GALAXY MUSIC`)
    .setURL(`https://discord.com/api/oauth2/authorize?client_id=953883710476918845&permissions=8&scope=bot`)
 .setStyle(`LINK`)                
      .setEmoji(`<a:online:1026095741179007056>`)
            let he = new MessageEmbed()
                            .setAuthor(`${client.user.username} - Help Menu`, client.user.displayAvatarURL())
            .setThumbnail(client.user.displayAvatarURL())
            .setColor(client.embedColor)
               .setDescription("<a:info:1026083391847796746> Hey, It's **VAYU ESPORTS** A Quality Multipurpose Bot With Breathtaking Features For Greater Experience While On Discord. **<a:premium:995321388359483412> VAYU RHYTHM and GALAXY MUSIC bots** Is Making Music More Enhanced In Discord. Try **<a:premium:995321388359483412> VAYU RHYTHM and GALAXY MUSIC BOTS** Now!")
              .addField("Developers",
                       `[Q U T Y P I E <3](https://discord.gg/Rqdx38Gdfn)`)
              .addField("Customizers",
                       `[ᴠᴀʏᴜ | Q U T Y P I E <3](https://discordapp.com/users/947891831516065834),  [₦ł₲H₮ ₣ɄⱤɎ](https://discordapp.com/users/761635564835045387)`)

            .setTimestamp()        
const row = new MessageActionRow()
      .addComponents(b, bt, website)

message.channel.send({embeds: [he], components: [row]})
        }};