const {
  MessageEmbed
} = require(`discord.js`);
const config = require(`../../botconfig/config.json`);
const ee = require(`../../botconfig/embed.json`);
const emoji = require(`../../botconfig/emojis.json`);

module.exports = {
  name: `join`,
  category: `Music`,
  aliases: [`j`],
  description: `Joins the Bot in your Channel`,
  usage: `join`,
  parameters: {"type":"radio", "activeplayer": false, "previoussong": false},
  run: async (client, message, args, guildData, player, prefix) => {

    if(player && player.voiceChannel && player.state === "CONNECTED") {
            return await message.channel.send({embeds: [new MessageEmbed().setColor(client.embedColor).setDescription( `I'm already connected to <#${player.voiceChannel}> voice channel!`)]})
        } else {
    
    
    const { channel } = message.member.voice;
   

   
   

     player = message.client.manager.create({
        guild: message.guild.id,
        voiceChannel: channel.id,
        textChannel: message.channel.id,
        volume: 100,
        selfDeafen: true,
      }) 
      if(player && player.state !== "CONNECTED") player.connect();

      let thing = new MessageEmbed()
        .setColor(client.embedColor)
        .setDescription(`<:DynoSuccess:983623619219423262>Joined <#${channel.id}>!`)
      return message.channel.send({ embeds: [thing] });

    };
  }
};